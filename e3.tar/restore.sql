--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.plazas DROP CONSTRAINT plazas_lid_fkey;
ALTER TABLE ONLY public.pinturas DROP CONSTRAINT pinturas_oid_fkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT paises_fk;
ALTER TABLE ONLY public.museos DROP CONSTRAINT museos_lid_fkey;
ALTER TABLE ONLY public.iglesias DROP CONSTRAINT iglesias_lid_fkey;
ALTER TABLE ONLY public.frescos DROP CONSTRAINT frescos_oid_fkey;
ALTER TABLE ONLY public.esculturas DROP CONSTRAINT esculturas_oid_fkey;
ALTER TABLE ONLY public.ubica_en DROP CONSTRAINT ubica_en_pkey;
ALTER TABLE ONLY public.realizo DROP CONSTRAINT realizo_pkey;
ALTER TABLE ONLY public.plazas DROP CONSTRAINT plazas_pkey;
ALTER TABLE ONLY public.pinturas DROP CONSTRAINT pinturas_pkey;
ALTER TABLE ONLY public.paises DROP CONSTRAINT paises_pkey;
ALTER TABLE ONLY public.obras DROP CONSTRAINT obras_pkey;
ALTER TABLE ONLY public.obras_en DROP CONSTRAINT obras_en_pkey;
ALTER TABLE ONLY public.museos DROP CONSTRAINT museos_pkey;
ALTER TABLE ONLY public.lugares DROP CONSTRAINT lugares_pkey;
ALTER TABLE ONLY public.iglesias DROP CONSTRAINT iglesias_pkey;
ALTER TABLE ONLY public.frescos DROP CONSTRAINT frescos_pkey;
ALTER TABLE ONLY public.esculturas DROP CONSTRAINT esculturas_pkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT ciudades_pkey;
ALTER TABLE ONLY public.artistas DROP CONSTRAINT artistas_pkey;
DROP TABLE public.ubica_en;
DROP TABLE public.realizo;
DROP TABLE public.plazas;
DROP TABLE public.pinturas;
DROP TABLE public.paises;
DROP TABLE public.obras_en;
DROP TABLE public.obras;
DROP TABLE public.museos;
DROP TABLE public.lugares;
DROP TABLE public.iglesias;
DROP TABLE public.frescos;
DROP TABLE public.esculturas;
DROP TABLE public.ciudades;
DROP TABLE public.artistas;
DROP FUNCTION public.tipos_lugares();
DROP FUNCTION public.fotos_obras();
DROP FUNCTION public.fotos_lugares();
DROP FUNCTION public.cid_artistas(lista_artistas character varying);
DROP EXTENSION dblink;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: cid_artistas(character varying); Type: FUNCTION; Schema: public; Owner: grupo84
--

CREATE FUNCTION public.cid_artistas(lista_artistas character varying) RETURNS TABLE(cid integer, nombre character varying)
    LANGUAGE plpgsql
    AS $_$
BEGIN
RETURN QUERY EXECUTE 'SELECT DISTINCT ubica_en.cid AS cid, artistas.nombre AS nombre
    FROM artistas, ciudades, obras, obras_en, realizo, ubica_en
    WHERE artistas.aid = realizo.aid AND obras.oid = realizo.oid AND obras.oid = obras_en.oid AND ubica_en.lid = obras_en.lid
    AND artistas.nombre IN $1'
        USING lista_artistas;
    RETURN;
END;
$_$;


ALTER FUNCTION public.cid_artistas(lista_artistas character varying) OWNER TO grupo84;

--
-- Name: fotos_lugares(); Type: FUNCTION; Schema: public; Owner: grupo84
--

CREATE FUNCTION public.fotos_lugares() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lugares SET foto_url= 'https://visitavirtual.info/wp-content/uploads/2017/08/piramide-museo-del-louvre.jpg' WHERE lid=1;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/Florence%2C_Italy_Uffizi_Museum_-_panoramio_%285%29.jpg/275px-Florence%2C_Italy_Uffizi_Museum_-_panoramio_%285%29.jpg' WHERE lid=2;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Basilica_di_San_Pietro_in_Vaticano_September_2015-1a.jpg/270px-Basilica_di_San_Pietro_in_Vaticano_September_2015-1a.jpg' WHERE lid=3;
    UPDATE lugares SET foto_url= 'https://turismo.org/wp-content/uploads/2013/04/Museos-Vaticanos-760x500.jpg' WHERE lid=4;
    UPDATE lugares SET foto_url= 'https://www.inexhibit.com/wp-content/uploads/2014/06/Royal-Academy-of-Arts-London-facade.jpg' WHERE lid=5;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Church_St_Maria_del_popolo_1.jpg/250px-Church_St_Maria_del_popolo_1.jpg' WHERE lid=6;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/Nancy_Musee_des_Beaux-Arts_BW_2015-07-18_13-55-20.jpg/275px-Nancy_Musee_des_Beaux-Arts_BW_2015-07-18_13-55-20.jpg' WHERE lid=7;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/36/Nuovo_museo_dell%27opera_del_duomo%2C_facciatone_arnolfiano_di_santa_maria_del_fiore%2C_000.jpg/200px-Nuovo_museo_dell%27opera_del_duomo%2C_facciatone_arnolfiano_di_santa_maria_del_fiore%2C_000.jpg' WHERE lid=8;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/View_of_Santa_Maria_del_Fiore_in_Florence.jpg/300px-View_of_Santa_Maria_del_Fiore_in_Florence.jpg' WHERE lid=9;
    UPDATE lugares SET foto_url= 'https://cdn.civitatis.com/italia/roma/galeria/thumbs/campo-dei-fiori.jpg' WHERE lid=10;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f0/Caspar_van_Wittel_-_Piazza_Navona%2C_Rome_-_Google_Art_Project.jpg/400px-Caspar_van_Wittel_-_Piazza_Navona%2C_Rome_-_Google_Art_Project.jpg' WHERE lid=11;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Santa_Maria_della_Vittoria_in_Rome_-_Front.jpg/250px-Santa_Maria_della_Vittoria_in_Rome_-_Front.jpg' WHERE lid=12;
    UPDATE lugares SET foto_url= 'https://sobreitalia.com/wp-content/uploads/2009/04/plaza-minerva-en-roma.jpg' WHERE lid=13;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d6/St_Peter%27s_Square%2C_Vatican_City_-_April_2007.jpg/300px-St_Peter%27s_Square%2C_Vatican_City_-_April_2007.jpg' WHERE lid=14;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Galleria_borghese_facade.jpg/275px-Galleria_borghese_facade.jpg' WHERE lid=15;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Broodhuis_Bruxelles.jpg/300px-Broodhuis_Bruxelles.jpg' WHERE lid=16;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0c/3048_-_Milano_-_S._Maria_delle_Grazie_-_Facciata_-_Foto_Giovanni_Dall%27Orto_-_6-Mar-2008.jpg/250px-3048_-_Milano_-_S._Maria_delle_Grazie_-_Facciata_-_Foto_Giovanni_Dall%27Orto_-_6-Mar-2008.jpg' WHERE lid=17;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/34/Galleria_dell%27accademia%2C_firenze.JPG/275px-Galleria_dell%27accademia%2C_firenze.JPG' WHERE lid=18;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/17/San_pietro_in_vincoli%2C_esterno.JPG/1024px-San_pietro_in_vincoli%2C_esterno.JPG' WHERE lid=19;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/82/Sistina-interno.jpg/270px-Sistina-interno.jpg' WHERE lid=20;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Dresden-Zwinger-Courtyard.11.JPG/275px-Dresden-Zwinger-Courtyard.11.JPG' WHERE lid=21;
    UPDATE lugares SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/76/Chateau_de_Chantilly_garden.jpg/275px-Chateau_de_Chantilly_garden.jpg' WHERE lid=22;
END
$$;


ALTER FUNCTION public.fotos_lugares() OWNER TO grupo84;

--
-- Name: fotos_obras(); Type: FUNCTION; Schema: public; Owner: grupo84
--

CREATE FUNCTION public.fotos_obras() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/4/4d/Andrea_Mantegna_089.jpg' WHERE oid=1;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/Annunciation_%28Leonardo%29.jpg/450px-Annunciation_%28Leonardo%29.jpg' WHERE oid=2;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/The_Baptism_of_Christ_%28Verrocchio_%26_Leonardo%29.jpg/800px-The_Baptism_of_Christ_%28Verrocchio_%26_Leonardo%29.jpg' WHERE oid=3;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/8/8c/Rome_basilica_st_peter_011c.jpg' WHERE oid=4;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Michelangelo_Caravaggio_052.jpg/800px-Michelangelo_Caravaggio_052.jpg' WHERE oid=5;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/22/Taddei_Tondo.JPG/1024px-Taddei_Tondo.JPG' WHERE oid=6;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Martirio_di_San_Pietro_September_2015-1a.jpg/368px-Martirio_di_San_Pietro_September_2015-1a.jpg' WHERE oid=7;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/6/6c/Caravaggio_-_The_Annunciation.JPG' WHERE oid=8;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/0/00/Medusa_by_Caravaggio.jpg' WHERE oid=9;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e1/Donatello%2C_maria_maddalena_02.JPG/420px-Donatello%2C_maria_maddalena_02.JPG' WHERE oid=10;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5d/Eug%C3%A8ne_Delacroix_-_Le_28_Juillet._La_Libert%C3%A9_guidant_le_peuple.jpg/450px-Eug%C3%A8ne_Delacroix_-_Le_28_Juillet._La_Libert%C3%A9_guidant_le_peuple.jpg' WHERE oid=11;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/b/bd/Giorgio_Vasari_-_The_Last_Judgment_-_WGA24313.jpg' WHERE oid=12;
    UPDATE obras SET foto_url= ' ' WHERE oid=13;
    UPDATE obras SET foto_url= ' ' WHERE oid=14;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Fountain_of_Neptune%2C_Rome.jpg/450px-Fountain_of_Neptune%2C_Rome.jpg' WHERE oid=15;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/7/76/Lazio_Roma_Navona2_tango7174.jpg' WHERE oid=16;
    UPDATE obras SET foto_url= ' ' WHERE oid=17;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/4c/Ecstasy_St_Theresa_SM_della_Vittoria.jpg/800px-Ecstasy_St_Theresa_SM_della_Vittoria.jpg' WHERE oid=18;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/ef/Minerveo_obelisk_in_front_of_Santa_Maria_sopra_Minerva.jpg/800px-Minerveo_obelisk_in_front_of_Santa_Maria_sopra_Minerva.jpg' WHERE oid=19;
    UPDATE obras SET foto_url= 'https://c8.alamy.com/compes/mf5rmy/la-columnata-de-gian-lorenzo-bernini-en-la-plaza-de-san-pedro-y-carlo-maderno-fachada-del-renacimiento-italiano-papale-basilica-maggiore-di-san-pietro-en-vatic-mf5rmy.jpg' WHERE oid=20;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Apollo_and_Daphne_%28Bernini%29.jpg/450px-Apollo_and_Daphne_%28Bernini%29.jpg' WHERE oid=21;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Giotto_di_Bondone_090.jpg/800px-Giotto_di_Bondone_090.jpg' WHERE oid=22;
    UPDATE obras SET foto_url= ' ' WHERE oid=23;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Giotto._The_Badia_Polyptych._c._1300._91x340cm._Uffizi%2C_Florence..jpg/1920px-Giotto._The_Badia_Polyptych._c._1300._91x340cm._Uffizi%2C_Florence..jpg' WHERE oid=24;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/Jacques-Louis_David_-_The_Coronation_of_Napoleon_%281805-1807%29.jpg/450px-Jacques-Louis_David_-_The_Coronation_of_Napoleon_%281805-1807%29.jpg' WHERE oid=25;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Bruxelles_Manneken_Pis.jpg/800px-Bruxelles_Manneken_Pis.jpg' WHERE oid=26;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/The_Last_Supper_-_Leonardo_Da_Vinci_-_High_Resolution_32x16.jpg/1920px-The_Last_Supper_-_Leonardo_Da_Vinci_-_High_Resolution_32x16.jpg' WHERE oid=27;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/73/Leonardo_da_Vinci_-_Mona_Lisa_%28Louvre%2C_Paris%29.jpg/800px-Leonardo_da_Vinci_-_Mona_Lisa_%28Louvre%2C_Paris%29.jpg' WHERE oid=28;
    UPDATE obras SET foto_url= 'https://cdn.culturagenial.com/es/imagenes/michelangelo-s-pieta-5450-cut-out-black-cke.jpg' WHERE oid=29;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Miguel_%C3%81ngel%2C_por_Daniele_da_Volterra_%28detalle%29.jpg/777px-Miguel_%C3%81ngel%2C_por_Daniele_da_Volterra_%28detalle%29.jpg' WHERE oid=31;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/5b/Michelangelo_-_Creation_of_Adam_%28cropped%29.jpg/1920px-Michelangelo_-_Creation_of_Adam_%28cropped%29.jpg' WHERE oid=32;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Last_Judgement_%28Michelangelo%29.jpg/800px-Last_Judgement_%28Michelangelo%29.jpg' WHERE oid=33;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/bb/1_Estancia_del_Sello_%28Vista_general_I%29.jpg/1280px-1_Estancia_del_Sello_%28Vista_general_I%29.jpg' WHERE oid=34;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/Transfiguration_Raphael.jpg/800px-Transfiguration_Raphael.jpg' WHERE oid=35;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/RAFAEL_-_Madonna_Sixtina_%28Gem%C3%A4ldegalerie_Alter_Meister%2C_Dresden%2C_1513-14._%C3%93leo_sobre_lienzo%2C_265_x_196_cm%29.jpg/800px-RAFAEL_-_Madonna_Sixtina_%28Gem%C3%A4ldegalerie_Alter_Meister%2C_Dresden%2C_1513-14._%C3%93leo_sobre_lienzo%2C_265_x_196_cm%29.jpg' WHERE oid=36;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/fe/Rapha%C3%ABl_-_Les_Trois_Gr%C3%A2ces_-_Google_Art_Project_2.jpg/1024px-Rapha%C3%ABl_-_Les_Trois_Gr%C3%A2ces_-_Google_Art_Project_2.jpg' WHERE oid=37;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/25/Sandro_Botticelli_-_La_Primavera_-_Google_Art_Project.jpg/1280px-Sandro_Botticelli_-_La_Primavera_-_Google_Art_Project.jpg' WHERE oid=38;
    UPDATE obras SET foto_url= 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg/1920px-Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg' WHERE oid=39;
END
$$;


ALTER FUNCTION public.fotos_obras() OWNER TO grupo84;

--
-- Name: tipos_lugares(); Type: FUNCTION; Schema: public; Owner: grupo84
--

CREATE FUNCTION public.tipos_lugares() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE lugares SET tipo= 'museo' WHERE lid=1;
    UPDATE lugares SET tipo= 'museo' WHERE lid=2;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=3;
    UPDATE lugares SET tipo= 'museo' WHERE lid=4;
    UPDATE lugares SET tipo= 'museo' WHERE lid=5;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=6;
    UPDATE lugares SET tipo= 'museo' WHERE lid=7;
    UPDATE lugares SET tipo= 'museo' WHERE lid=8;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=9;
    UPDATE lugares SET tipo= 'plaza' WHERE lid=10;
    UPDATE lugares SET tipo= 'plaza' WHERE lid=11;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=12;
    UPDATE lugares SET tipo= 'plaza' WHERE lid=13;
    UPDATE lugares SET tipo= 'plaza' WHERE lid=14;
    UPDATE lugares SET tipo= 'museo' WHERE lid=15;
    UPDATE lugares SET tipo= 'museo' WHERE lid=16;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=17;
    UPDATE lugares SET tipo= 'museo' WHERE lid=18;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=19;
    UPDATE lugares SET tipo= 'iglesia' WHERE lid=20;
    UPDATE lugares SET tipo= 'museo' WHERE lid=21;
    UPDATE lugares SET tipo= 'museo' WHERE lid=22;
END
$$;


ALTER FUNCTION public.tipos_lugares() OWNER TO grupo84;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: artistas; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.artistas (
    aid integer NOT NULL,
    nombre character varying(255),
    fecha_nac date,
    fecha_fall date,
    descripcion text,
    foto_url text
);


ALTER TABLE public.artistas OWNER TO grupo84;

--
-- Name: ciudades; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.ciudades (
    cid integer NOT NULL,
    nombre character varying(100),
    pais character varying(100)
);


ALTER TABLE public.ciudades OWNER TO grupo84;

--
-- Name: esculturas; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.esculturas (
    oid integer NOT NULL,
    material character varying(100)
);


ALTER TABLE public.esculturas OWNER TO grupo84;

--
-- Name: frescos; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.frescos (
    oid integer NOT NULL
);


ALTER TABLE public.frescos OWNER TO grupo84;

--
-- Name: iglesias; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.iglesias (
    lid integer NOT NULL,
    horario_in time without time zone,
    horario_fin time without time zone
);


ALTER TABLE public.iglesias OWNER TO grupo84;

--
-- Name: lugares; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.lugares (
    lid integer NOT NULL,
    nombre character varying(100),
    foto_url text,
    tipo text
);


ALTER TABLE public.lugares OWNER TO grupo84;

--
-- Name: museos; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.museos (
    lid integer NOT NULL,
    precio integer,
    horario_in time without time zone,
    horario_fin time without time zone
);


ALTER TABLE public.museos OWNER TO grupo84;

--
-- Name: obras; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.obras (
    oid integer NOT NULL,
    nombre character varying(100),
    fecha_in date,
    fecha_fin date,
    periodo character varying(100),
    foto_url text
);


ALTER TABLE public.obras OWNER TO grupo84;

--
-- Name: obras_en; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.obras_en (
    oid integer NOT NULL,
    lid integer NOT NULL
);


ALTER TABLE public.obras_en OWNER TO grupo84;

--
-- Name: paises; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.paises (
    nombre character varying(50) NOT NULL,
    telefono integer
);


ALTER TABLE public.paises OWNER TO grupo84;

--
-- Name: pinturas; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.pinturas (
    oid integer NOT NULL,
    tecnica character varying(100)
);


ALTER TABLE public.pinturas OWNER TO grupo84;

--
-- Name: plazas; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.plazas (
    lid integer NOT NULL
);


ALTER TABLE public.plazas OWNER TO grupo84;

--
-- Name: realizo; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.realizo (
    aid integer NOT NULL,
    oid integer NOT NULL
);


ALTER TABLE public.realizo OWNER TO grupo84;

--
-- Name: ubica_en; Type: TABLE; Schema: public; Owner: grupo84
--

CREATE TABLE public.ubica_en (
    lid integer NOT NULL,
    cid integer NOT NULL
);


ALTER TABLE public.ubica_en OWNER TO grupo84;

--
-- Data for Name: artistas; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.artistas (aid, nombre, fecha_nac, fecha_fall, descripcion, foto_url) FROM stdin;
\.
COPY public.artistas (aid, nombre, fecha_nac, fecha_fall, descripcion, foto_url) FROM '$$PATH$$/3044.dat';

--
-- Data for Name: ciudades; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.ciudades (cid, nombre, pais) FROM stdin;
\.
COPY public.ciudades (cid, nombre, pais) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: esculturas; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.esculturas (oid, material) FROM stdin;
\.
COPY public.esculturas (oid, material) FROM '$$PATH$$/3046.dat';

--
-- Data for Name: frescos; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.frescos (oid) FROM stdin;
\.
COPY public.frescos (oid) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: iglesias; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.iglesias (lid, horario_in, horario_fin) FROM stdin;
\.
COPY public.iglesias (lid, horario_in, horario_fin) FROM '$$PATH$$/3048.dat';

--
-- Data for Name: lugares; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.lugares (lid, nombre, foto_url, tipo) FROM stdin;
\.
COPY public.lugares (lid, nombre, foto_url, tipo) FROM '$$PATH$$/3049.dat';

--
-- Data for Name: museos; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.museos (lid, precio, horario_in, horario_fin) FROM stdin;
\.
COPY public.museos (lid, precio, horario_in, horario_fin) FROM '$$PATH$$/3050.dat';

--
-- Data for Name: obras; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.obras (oid, nombre, fecha_in, fecha_fin, periodo, foto_url) FROM stdin;
\.
COPY public.obras (oid, nombre, fecha_in, fecha_fin, periodo, foto_url) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: obras_en; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.obras_en (oid, lid) FROM stdin;
\.
COPY public.obras_en (oid, lid) FROM '$$PATH$$/3052.dat';

--
-- Data for Name: paises; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.paises (nombre, telefono) FROM stdin;
\.
COPY public.paises (nombre, telefono) FROM '$$PATH$$/3053.dat';

--
-- Data for Name: pinturas; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.pinturas (oid, tecnica) FROM stdin;
\.
COPY public.pinturas (oid, tecnica) FROM '$$PATH$$/3054.dat';

--
-- Data for Name: plazas; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.plazas (lid) FROM stdin;
\.
COPY public.plazas (lid) FROM '$$PATH$$/3055.dat';

--
-- Data for Name: realizo; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.realizo (aid, oid) FROM stdin;
\.
COPY public.realizo (aid, oid) FROM '$$PATH$$/3056.dat';

--
-- Data for Name: ubica_en; Type: TABLE DATA; Schema: public; Owner: grupo84
--

COPY public.ubica_en (lid, cid) FROM stdin;
\.
COPY public.ubica_en (lid, cid) FROM '$$PATH$$/3057.dat';

--
-- Name: artistas artistas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.artistas
    ADD CONSTRAINT artistas_pkey PRIMARY KEY (aid);


--
-- Name: ciudades ciudades_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT ciudades_pkey PRIMARY KEY (cid);


--
-- Name: esculturas esculturas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.esculturas
    ADD CONSTRAINT esculturas_pkey PRIMARY KEY (oid);


--
-- Name: frescos frescos_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.frescos
    ADD CONSTRAINT frescos_pkey PRIMARY KEY (oid);


--
-- Name: iglesias iglesias_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.iglesias
    ADD CONSTRAINT iglesias_pkey PRIMARY KEY (lid);


--
-- Name: lugares lugares_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.lugares
    ADD CONSTRAINT lugares_pkey PRIMARY KEY (lid);


--
-- Name: museos museos_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.museos
    ADD CONSTRAINT museos_pkey PRIMARY KEY (lid);


--
-- Name: obras_en obras_en_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.obras_en
    ADD CONSTRAINT obras_en_pkey PRIMARY KEY (oid, lid);


--
-- Name: obras obras_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.obras
    ADD CONSTRAINT obras_pkey PRIMARY KEY (oid);


--
-- Name: paises paises_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.paises
    ADD CONSTRAINT paises_pkey PRIMARY KEY (nombre);


--
-- Name: pinturas pinturas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.pinturas
    ADD CONSTRAINT pinturas_pkey PRIMARY KEY (oid);


--
-- Name: plazas plazas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.plazas
    ADD CONSTRAINT plazas_pkey PRIMARY KEY (lid);


--
-- Name: realizo realizo_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.realizo
    ADD CONSTRAINT realizo_pkey PRIMARY KEY (aid, oid);


--
-- Name: ubica_en ubica_en_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.ubica_en
    ADD CONSTRAINT ubica_en_pkey PRIMARY KEY (lid, cid);


--
-- Name: esculturas esculturas_oid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.esculturas
    ADD CONSTRAINT esculturas_oid_fkey FOREIGN KEY (oid) REFERENCES public.obras(oid);


--
-- Name: frescos frescos_oid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.frescos
    ADD CONSTRAINT frescos_oid_fkey FOREIGN KEY (oid) REFERENCES public.obras(oid);


--
-- Name: iglesias iglesias_lid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.iglesias
    ADD CONSTRAINT iglesias_lid_fkey FOREIGN KEY (lid) REFERENCES public.lugares(lid);


--
-- Name: museos museos_lid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.museos
    ADD CONSTRAINT museos_lid_fkey FOREIGN KEY (lid) REFERENCES public.lugares(lid);


--
-- Name: ciudades paises_fk; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT paises_fk FOREIGN KEY (pais) REFERENCES public.paises(nombre);


--
-- Name: pinturas pinturas_oid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.pinturas
    ADD CONSTRAINT pinturas_oid_fkey FOREIGN KEY (oid) REFERENCES public.obras(oid);


--
-- Name: plazas plazas_lid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo84
--

ALTER TABLE ONLY public.plazas
    ADD CONSTRAINT plazas_lid_fkey FOREIGN KEY (lid) REFERENCES public.lugares(lid);


--
-- PostgreSQL database dump complete
--

