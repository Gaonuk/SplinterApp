--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_uid_fkey;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_did_fkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_uid_fkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_hid_fkey;
ALTER TABLE ONLY public.hoteles DROP CONSTRAINT hoteles_nombreciudad_fkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_ciudadorigen_fkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_ciudaddestino_fkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT ciudades_nombrepais_fkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_username_key;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_pkey;
ALTER TABLE ONLY public.paises DROP CONSTRAINT paises_pkey;
ALTER TABLE ONLY public.hoteles DROP CONSTRAINT hoteles_pkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_pkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT ciudades_pkey;
DROP TABLE public.usuarios;
DROP TABLE public.tickets;
DROP TABLE public.reservas;
DROP TABLE public.paises;
DROP TABLE public.hoteles;
DROP TABLE public.entradas;
DROP TABLE public.destinos;
DROP TABLE public.ciudades;
DROP FUNCTION public.f_itinerario(fecha date, origen character varying, nombre_artistas character varying);
DROP EXTENSION dblink;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: dblink; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS dblink WITH SCHEMA public;


--
-- Name: EXTENSION dblink; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION dblink IS 'connect to other PostgreSQL databases from within a database';


--
-- Name: f_itinerario(date, character varying, character varying); Type: FUNCTION; Schema: public; Owner: grupo15
--

CREATE FUNCTION public.f_itinerario(fecha date, origen character varying, nombre_artistas character varying) RETURNS TABLE(tid integer, c1 character varying, c2 character varying, hora_salida1 timestamp without time zone, duracion1 integer, medio1 character varying, precio1 integer, c3 character varying, c4 character varying, hora_salida2 timestamp without time zone, duracion2 integer, medio2 character varying, precio2 integer, c5 character varying, c6 character varying, hora_salida3 timestamp without time zone, duracion3 integer, medio3 character varying, precio3 integer, total integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
viajes RECORD;
prow RECORD;
tiene_escala1 INT;
tiene_escala2 INT;
trow RECORD;
viaje1 INT;
viaje2 INT;
viaje3 INT;
vrow RECORD;
hora_llegada TIMESTAMP;
BEGIN
	--Obtiene el id de la ciudad de origen
    DROP TABLE IF EXISTS origen_id;
	CREATE TEMP TABLE IF NOT EXISTS origen_id AS
		(SELECT DISTINCT cid FROM ciudades WHERE nombreciudad = origen);
	
	--Obtiene los id de las ciudades segun artistas
    DROP TABLE IF EXISTS ciudades_id;
	CREATE TEMP TABLE IF NOT EXISTS ciudades_id AS
        (SELECT DISTINCT cid_artistas.cid FROM
		(SELECT artistas_cid.cid, artistas_cid.nombre
		FROM dblink('dbname=grupo84e3 user=grupo84 password=grupo84', '
		SELECT ubica_en.cid, artista_lugar.nombre
		FROM ubica_en,
			(SELECT obras_artista.aid, obras_en.oid, obras_en.lid, obras_artista.nombre
					FROM obras_en,
						(SELECT oid, artistas.aid, nombre FROM artistas, realizo
							WHERE artistas.aid = realizo.aid) AS obras_artista
					WHERE obras_en.oid = obras_artista.oid) AS artista_lugar
		WHERE ubica_en.lid = artista_lugar.lid'
		) AS artistas_cid(cid int, nombre varchar(50)),
		string_to_array(nombre_artistas, ',') AS nombre_array(nombre)
		WHERE artistas_cid.nombre =ANY(nombre_array.nombre)) AS cid_artistas);

	--Obtiene todos los viajes posible a maximo dos escalas
    DROP TABLE IF EXISTS viajes;
	CREATE TEMP TABLE IF NOT EXISTS viajes AS
		(WITH RECURSIVE alcanzo(ciudadorigen, ciudaddestino, counter, escala1, escala2, did) AS
			(
				SELECT destinos.ciudadorigen, destinos.ciudaddestino, 1, 0, 0, TEXT(destinos.did) FROM destinos

				UNION

				SELECT D.ciudadorigen, A.ciudaddestino, A.counter + 1, 
						CASE WHEN A.counter = 1 THEN A.escala1 + D.ciudaddestino ELSE A.escala1 END, 
						CASE WHEN A.counter = 2 THEN A.escala2 + D.ciudaddestino ELSE A.escala2 END,
						CONCAT(A.did, '/', D.did)
				FROM destinos D, alcanzo A, origen_id, ciudades_id
				WHERE D.ciudaddestino = A.ciudadorigen AND A.counter <= 2 
				AND D.ciudaddestino != origen_id.cid AND D.ciudaddestino = ciudades_id.cid
			)
		SELECT * FROM alcanzo);

	--Obtiene los id de los viajes que nos interesa segun el origen y las ciudades que queremos visitar
	DROP TABLE IF EXISTS planificacion;
	CREATE TEMP TABLE IF NOT EXISTS planificacion AS
		SELECT split_part(V.did, '/', 3) as v1, split_part(V.did, '/', 2) as v2, split_part(V.did, '/', 1) as v3  
			FROM (SELECT * FROM viajes) AS V, ciudades_id, origen_id 
			WHERE V.ciudaddestino = ciudades_id.cid AND V.ciudadorigen = origen_id.cid AND
			V.ciudaddestino != origen_id.cid AND V.ciudaddestino != V.escala2;
	
	--Crea tabla para poblar los itinerarios
	DROP TABLE IF EXISTS itinerario;
	CREATE TEMP TABLE IF NOT EXISTS itinerario(tid SERIAL, c1 varchar, c2 varchar(50), hora_salida1 TIMESTAMP, duracion1 INT, medio1 varchar, precio1 INT,
														c3 varchar, c4 varchar, hora_salida2 TIMESTAMP, duracion2 int, medio2 varchar, precio2 int,
														c5 varchar, c6 varchar, hora_salida3 TIMESTAMP, duracion3 int, medio3 varchar, precio3 int, total INT);
	
	--Poblar tabla de itinerario

	FOR prow IN
			SELECT * FROM planificacion
		LOOP

			--Caso que ocupe tres viajes
			IF prow.v1 != '' THEN
				viaje1 := CAST(prow.v1 AS INTEGER);
				viaje2 := CAST(prow.v2 AS INTEGER);
				viaje3 := CAST(prow.v3 AS INTEGER);

				DROP TABLE IF EXISTS v1;
				CREATE TEMP TABLE IF NOT EXISTS v1 AS
				SELECT * FROM destinos WHERE did = viaje1;
				DROP TABLE IF EXISTS v2;
				CREATE TEMP TABLE IF NOT EXISTS v2 AS
				SELECT * FROM destinos WHERE did = viaje2;
				DROP TABLE IF EXISTS v3;
				CREATE TEMP TABLE IF NOT EXISTS v3 AS
				SELECT * FROM destinos WHERE did = viaje3;

				INSERT INTO itinerario (c1, c2, hora_salida1, duracion1, medio1, precio1, c3, c4, hora_salida2, duracion2, medio2, precio2, c5, c6, hora_salida3, duracion3, medio3, precio3, total)
					SELECT  c1.nombreciudad, c2.nombreciudad, fecha + v1.horasalida, v1.duracion, v1.medio, v1.precio,
								c3.nombreciudad, c4.nombreciudad, fecha + v2.horasalida, v2.duracion, v2.medio, v2.precio,
								c5.nombreciudad, c6.nombreciudad, fecha + v3.horasalida, v3.duracion, v3.medio, v3.precio, v1.precio + v2.precio + v3.precio
					FROM v1, v2, v3, ciudades AS c1, ciudades AS c2, ciudades AS c3, ciudades AS c4, ciudades AS c5, ciudades AS c6
					WHERE c1.cid = v1.ciudadorigen AND c2.cid = v1.ciudaddestino AND
						c3.cid = v2.ciudadorigen AND c4.cid = v2.ciudaddestino AND
						c5.cid = v3.ciudadorigen AND c6.cid = v3.ciudaddestino;

			--Caso que ocupe dos viajes
			ELSEIF prow.v2 != '' THEN
                viaje1 := CAST(prow.v2 AS INTEGER);
				viaje2 := CAST(prow.v3 AS INTEGER);
				DROP TABLE IF EXISTS v1;
				CREATE TEMP TABLE IF NOT EXISTS v1 AS
				SELECT * FROM destinos WHERE did = viaje1;
				DROP TABLE IF EXISTS v2;
				CREATE TEMP TABLE IF NOT EXISTS v2 AS
				SELECT * FROM destinos WHERE did = viaje2;

			INSERT INTO itinerario (c1, c2, hora_salida1, duracion1, medio1, precio1, c3, c4, hora_salida2, duracion2, medio2, precio2, total)
					SELECT  c1.nombreciudad, c2.nombreciudad, fecha + v1.horasalida, v1.duracion, v1.medio, v1.precio,
								c3.nombreciudad, c4.nombreciudad, fecha + v2.horasalida, v2.duracion, v2.medio, v2.precio, v1.precio + v2.precio

					FROM v1, v2, ciudades AS c1, ciudades AS c2, ciudades AS c3, ciudades AS c4
					WHERE c1.cid = v1.ciudadorigen AND c2.cid = v1.ciudaddestino AND
						c3.cid = v2.ciudadorigen AND c4.cid = v2.ciudaddestino;

			--Caso que ocupe un viaje
			ELSE
				viaje1 := CAST(prow.v3 AS INTEGER);
				DROP TABLE IF EXISTS v1;
				CREATE TEMP TABLE IF NOT EXISTS v1 AS
				SELECT * FROM destinos WHERE did = viaje1;

			INSERT INTO itinerario (c1, c2, hora_salida1, duracion1, medio1, precio1, total)
					SELECT  c1.nombreciudad, c2.nombreciudad, fecha + v1.horasalida, v1.duracion, v1.medio, v1.precio, v1.precio

					FROM v1, ciudades AS c1, ciudades AS c2
					WHERE c1.cid = v1.ciudadorigen AND c2.cid = v1.ciudaddestino;
			END IF;

		END LOOP;

	FOR prow IN
		SELECT * FROM itinerario
	LOOP
		IF prow.c3 IS NOT NULL THEN
			hora_llegada := prow.hora_salida1 + interval '1' HOUR * prow.duracion1;
			LOOP
				IF hora_llegada < prow.hora_salida2 THEN
					EXIT;
				END IF;
				prow.hora_salida2 := prow.hora_salida2 + interval '1' day;
			END LOOP;
			UPDATE itinerario SET hora_salida2= prow.hora_salida2 WHERE itinerario.tid = prow.tid;

			IF prow.c5 IS NOT NULL THEN
				hora_llegada := prow.hora_salida2 + interval '1' HOUR * prow.duracion2;
				LOOP
				IF hora_llegada < prow.hora_salida3 THEN
					EXIT;
				END IF;
				prow.hora_salida3 := prow.hora_salida3 + interval '1' day;
			END LOOP;
			UPDATE itinerario SET hora_salida3= prow.hora_salida3 WHERE itinerario.tid = prow.tid;
			END IF;
		END IF;

	END LOOP;


	RETURN QUERY SELECT i.tid,
	i.c1, i.c2, i.hora_salida1, i.duracion1, i.medio1, i.precio1,
	i.c3, i.c4, i.hora_salida2, i.duracion2, i.medio2, i.precio2,
	i.c5, i.c6, i.hora_salida3, i.duracion3, i.medio3, i.precio3,
	i.total  FROM itinerario as i ORDER BY total;
RETURN;
END;
$$;


ALTER FUNCTION public.f_itinerario(fecha date, origen character varying, nombre_artistas character varying) OWNER TO grupo15;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ciudades; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.ciudades (
    cid integer NOT NULL,
    nombreciudad character varying(20),
    nombrepais character varying(20)
);


ALTER TABLE public.ciudades OWNER TO grupo15;

--
-- Name: destinos; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.destinos (
    did integer NOT NULL,
    ciudadorigen integer,
    ciudaddestino integer,
    horasalida time without time zone,
    duracion integer,
    medio character varying(20),
    capacidad integer,
    precio integer
);


ALTER TABLE public.destinos OWNER TO grupo15;

--
-- Name: entradas; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.entradas (
    uid integer,
    mid integer,
    fechaactual date
);


ALTER TABLE public.entradas OWNER TO grupo15;

--
-- Name: hoteles; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.hoteles (
    hid integer NOT NULL,
    nombrehotel character varying(40),
    direccionhotel character varying,
    telefono character varying(20),
    precionoche integer,
    nombreciudad integer
);


ALTER TABLE public.hoteles OWNER TO grupo15;

--
-- Name: paises; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.paises (
    nombrepais character varying(20) NOT NULL,
    fonocontacto character varying(20)
);


ALTER TABLE public.paises OWNER TO grupo15;

--
-- Name: reservas; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.reservas (
    rid integer NOT NULL,
    uid integer,
    fechainicio date,
    fechatermino date,
    hid integer
);


ALTER TABLE public.reservas OWNER TO grupo15;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.tickets (
    uid integer,
    asiento integer,
    fechacompra timestamp without time zone,
    fechaviaje date,
    did integer,
    tid integer NOT NULL
);


ALTER TABLE public.tickets OWNER TO grupo15;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.usuarios (
    uid integer NOT NULL,
    nombreusuario character varying(50),
    username character varying(20),
    correo character varying(40),
    direccionusuario character varying,
    password character varying DEFAULT 0 NOT NULL
);


ALTER TABLE public.usuarios OWNER TO grupo15;

--
-- Data for Name: ciudades; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.ciudades (cid, nombreciudad, nombrepais) FROM stdin;
\.
COPY public.ciudades (cid, nombreciudad, nombrepais) FROM '$$PATH$$/3072.dat';

--
-- Data for Name: destinos; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.destinos (did, ciudadorigen, ciudaddestino, horasalida, duracion, medio, capacidad, precio) FROM stdin;
\.
COPY public.destinos (did, ciudadorigen, ciudaddestino, horasalida, duracion, medio, capacidad, precio) FROM '$$PATH$$/3073.dat';

--
-- Data for Name: entradas; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.entradas (uid, mid, fechaactual) FROM stdin;
\.
COPY public.entradas (uid, mid, fechaactual) FROM '$$PATH$$/3079.dat';

--
-- Data for Name: hoteles; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.hoteles (hid, nombrehotel, direccionhotel, telefono, precionoche, nombreciudad) FROM stdin;
\.
COPY public.hoteles (hid, nombrehotel, direccionhotel, telefono, precionoche, nombreciudad) FROM '$$PATH$$/3074.dat';

--
-- Data for Name: paises; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.paises (nombrepais, fonocontacto) FROM stdin;
\.
COPY public.paises (nombrepais, fonocontacto) FROM '$$PATH$$/3075.dat';

--
-- Data for Name: reservas; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.reservas (rid, uid, fechainicio, fechatermino, hid) FROM stdin;
\.
COPY public.reservas (rid, uid, fechainicio, fechatermino, hid) FROM '$$PATH$$/3076.dat';

--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.tickets (uid, asiento, fechacompra, fechaviaje, did, tid) FROM stdin;
\.
COPY public.tickets (uid, asiento, fechacompra, fechaviaje, did, tid) FROM '$$PATH$$/3077.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.usuarios (uid, nombreusuario, username, correo, direccionusuario, password) FROM stdin;
\.
COPY public.usuarios (uid, nombreusuario, username, correo, direccionusuario, password) FROM '$$PATH$$/3078.dat';

--
-- Name: ciudades ciudades_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT ciudades_pkey PRIMARY KEY (cid);


--
-- Name: destinos destinos_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_pkey PRIMARY KEY (did);


--
-- Name: hoteles hoteles_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.hoteles
    ADD CONSTRAINT hoteles_pkey PRIMARY KEY (hid);


--
-- Name: paises paises_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.paises
    ADD CONSTRAINT paises_pkey PRIMARY KEY (nombrepais);


--
-- Name: reservas reservas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_pkey PRIMARY KEY (rid);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (tid);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (uid);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: ciudades ciudades_nombrepais_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT ciudades_nombrepais_fkey FOREIGN KEY (nombrepais) REFERENCES public.paises(nombrepais) ON DELETE CASCADE;


--
-- Name: destinos destinos_ciudaddestino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_ciudaddestino_fkey FOREIGN KEY (ciudaddestino) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: destinos destinos_ciudadorigen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_ciudadorigen_fkey FOREIGN KEY (ciudadorigen) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: hoteles hoteles_nombreciudad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.hoteles
    ADD CONSTRAINT hoteles_nombreciudad_fkey FOREIGN KEY (nombreciudad) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: reservas reservas_hid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_hid_fkey FOREIGN KEY (hid) REFERENCES public.hoteles(hid) ON DELETE CASCADE;


--
-- Name: reservas reservas_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_uid_fkey FOREIGN KEY (uid) REFERENCES public.usuarios(uid) ON DELETE SET NULL;


--
-- Name: tickets tickets_did_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_did_fkey FOREIGN KEY (did) REFERENCES public.destinos(did) ON DELETE CASCADE;


--
-- Name: tickets tickets_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_uid_fkey FOREIGN KEY (uid) REFERENCES public.usuarios(uid) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

