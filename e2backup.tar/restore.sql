--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_uid_fkey;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_did_fkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_uid_fkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_hid_fkey;
ALTER TABLE ONLY public.hoteles DROP CONSTRAINT hoteles_nombreciudad_fkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_ciudadorigen_fkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_ciudaddestino_fkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT ciudades_nombrepais_fkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_username_key;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.tickets DROP CONSTRAINT tickets_pkey;
ALTER TABLE ONLY public.reservas DROP CONSTRAINT reservas_pkey;
ALTER TABLE ONLY public.paises DROP CONSTRAINT paises_pkey;
ALTER TABLE ONLY public.hoteles DROP CONSTRAINT hoteles_pkey;
ALTER TABLE ONLY public.destinos DROP CONSTRAINT destinos_pkey;
ALTER TABLE ONLY public.ciudades DROP CONSTRAINT ciudades_pkey;
DROP TABLE public.usuarios;
DROP TABLE public.tickets;
DROP TABLE public.reservas;
DROP TABLE public.paises;
DROP TABLE public.hoteles;
DROP TABLE public.destinos;
DROP TABLE public.ciudades;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: ciudades; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.ciudades (
    cid integer NOT NULL,
    nombreciudad character varying(20),
    nombrepais character varying(20)
);


ALTER TABLE public.ciudades OWNER TO grupo15;

--
-- Name: destinos; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.destinos (
    did integer NOT NULL,
    ciudadorigen integer,
    ciudaddestino integer,
    horasalida time without time zone,
    duracion integer,
    medio character varying(20),
    capacidad integer,
    precio integer
);


ALTER TABLE public.destinos OWNER TO grupo15;

--
-- Name: hoteles; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.hoteles (
    hid integer NOT NULL,
    nombrehotel character varying(40),
    direccionhotel character varying,
    telefono character varying(20),
    precionoche integer,
    nombreciudad integer
);


ALTER TABLE public.hoteles OWNER TO grupo15;

--
-- Name: paises; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.paises (
    nombrepais character varying(20) NOT NULL,
    fonocontacto character varying(20)
);


ALTER TABLE public.paises OWNER TO grupo15;

--
-- Name: reservas; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.reservas (
    rid integer NOT NULL,
    uid integer,
    fechainicio date,
    fechatermino date,
    hid integer
);


ALTER TABLE public.reservas OWNER TO grupo15;

--
-- Name: tickets; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.tickets (
    uid integer,
    asiento integer,
    fechacompra timestamp without time zone,
    fechaviaje date,
    did integer,
    tid integer NOT NULL
);


ALTER TABLE public.tickets OWNER TO grupo15;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: grupo15
--

CREATE TABLE public.usuarios (
    uid integer NOT NULL,
    nombreusuario character varying(50),
    username character varying(20),
    correo character varying(40),
    direccionusuario character varying
);


ALTER TABLE public.usuarios OWNER TO grupo15;

--
-- Data for Name: ciudades; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.ciudades (cid, nombreciudad, nombrepais) FROM stdin;
\.
COPY public.ciudades (cid, nombreciudad, nombrepais) FROM '$$PATH$$/2955.dat';

--
-- Data for Name: destinos; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.destinos (did, ciudadorigen, ciudaddestino, horasalida, duracion, medio, capacidad, precio) FROM stdin;
\.
COPY public.destinos (did, ciudadorigen, ciudaddestino, horasalida, duracion, medio, capacidad, precio) FROM '$$PATH$$/2957.dat';

--
-- Data for Name: hoteles; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.hoteles (hid, nombrehotel, direccionhotel, telefono, precionoche, nombreciudad) FROM stdin;
\.
COPY public.hoteles (hid, nombrehotel, direccionhotel, telefono, precionoche, nombreciudad) FROM '$$PATH$$/2956.dat';

--
-- Data for Name: paises; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.paises (nombrepais, fonocontacto) FROM stdin;
\.
COPY public.paises (nombrepais, fonocontacto) FROM '$$PATH$$/2954.dat';

--
-- Data for Name: reservas; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.reservas (rid, uid, fechainicio, fechatermino, hid) FROM stdin;
\.
COPY public.reservas (rid, uid, fechainicio, fechatermino, hid) FROM '$$PATH$$/2959.dat';

--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.tickets (uid, asiento, fechacompra, fechaviaje, did, tid) FROM stdin;
\.
COPY public.tickets (uid, asiento, fechacompra, fechaviaje, did, tid) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: grupo15
--

COPY public.usuarios (uid, nombreusuario, username, correo, direccionusuario) FROM stdin;
\.
COPY public.usuarios (uid, nombreusuario, username, correo, direccionusuario) FROM '$$PATH$$/2953.dat';

--
-- Name: ciudades ciudades_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT ciudades_pkey PRIMARY KEY (cid);


--
-- Name: destinos destinos_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_pkey PRIMARY KEY (did);


--
-- Name: hoteles hoteles_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.hoteles
    ADD CONSTRAINT hoteles_pkey PRIMARY KEY (hid);


--
-- Name: paises paises_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.paises
    ADD CONSTRAINT paises_pkey PRIMARY KEY (nombrepais);


--
-- Name: reservas reservas_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_pkey PRIMARY KEY (rid);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (tid);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (uid);


--
-- Name: usuarios usuarios_username_key; Type: CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_username_key UNIQUE (username);


--
-- Name: ciudades ciudades_nombrepais_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.ciudades
    ADD CONSTRAINT ciudades_nombrepais_fkey FOREIGN KEY (nombrepais) REFERENCES public.paises(nombrepais) ON DELETE CASCADE;


--
-- Name: destinos destinos_ciudaddestino_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_ciudaddestino_fkey FOREIGN KEY (ciudaddestino) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: destinos destinos_ciudadorigen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.destinos
    ADD CONSTRAINT destinos_ciudadorigen_fkey FOREIGN KEY (ciudadorigen) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: hoteles hoteles_nombreciudad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.hoteles
    ADD CONSTRAINT hoteles_nombreciudad_fkey FOREIGN KEY (nombreciudad) REFERENCES public.ciudades(cid) ON DELETE CASCADE;


--
-- Name: reservas reservas_hid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_hid_fkey FOREIGN KEY (hid) REFERENCES public.hoteles(hid) ON DELETE CASCADE;


--
-- Name: reservas reservas_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.reservas
    ADD CONSTRAINT reservas_uid_fkey FOREIGN KEY (uid) REFERENCES public.usuarios(uid) ON DELETE CASCADE;


--
-- Name: tickets tickets_did_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_did_fkey FOREIGN KEY (did) REFERENCES public.destinos(did) ON DELETE CASCADE;


--
-- Name: tickets tickets_uid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: grupo15
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_uid_fkey FOREIGN KEY (uid) REFERENCES public.usuarios(uid) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

